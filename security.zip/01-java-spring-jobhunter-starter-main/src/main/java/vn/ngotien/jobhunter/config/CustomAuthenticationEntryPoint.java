package vn.ngotien.jobhunter.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.server.resource.web.BearerTokenAuthenticationEntryPoint;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import vn.ngotien.jobhunter.domain.RestResponse;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

  private final AuthenticationEntryPoint delegate = new BearerTokenAuthenticationEntryPoint();

  private final ObjectMapper mapper;

  public CustomAuthenticationEntryPoint(ObjectMapper mapper) {
    this.mapper = mapper;
  }

  @Override
  public void commence(HttpServletRequest request, HttpServletResponse response,
      org.springframework.security.core.AuthenticationException authException)
      throws IOException, ServletException {
    this.delegate.commence(request,
        response,
        authException);
    response.setContentType("application/json;charset=UTF-8");

    RestResponse<Object> restResponse = new RestResponse<Object>();
    restResponse.setStatusCode(HttpStatus.UNAUTHORIZED.value());

    String errorMessage = Optional.ofNullable(authException.getCause())
        .map(Throwable::getMessage)
        .orElse(authException.getMessage());
    restResponse.setMessage(errorMessage);

    restResponse.setMessage("Token không hợp lệ (hết hạn , không đúng định dạng or sai !!!)");

    mapper.writeValue(response.getWriter(), restResponse);
  }
}
