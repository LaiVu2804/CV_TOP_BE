package vn.ngotien.jobhunter.controller;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.ngotien.jobhunter.domain.User;
import vn.ngotien.jobhunter.domain.dto.LoginDTO;
import vn.ngotien.jobhunter.domain.dto.RestLoginDTO;
import vn.ngotien.jobhunter.service.UserService;
import vn.ngotien.jobhunter.util.SecurityUtil;

@RestController
@RequestMapping("/api/v1")
public class AuthController {

  private final AuthenticationManagerBuilder authenticationManagerBuilder;

  private final SecurityUtil securityUtil;
  private final UserService userService;

  public AuthController(AuthenticationManagerBuilder authenticationManagerBuilder,
      SecurityUtil securityUtil, UserService userService) {

    this.authenticationManagerBuilder = authenticationManagerBuilder;
    this.securityUtil = securityUtil;
    this.userService = userService;
  }

  @PostMapping("/login")
  public ResponseEntity<RestLoginDTO> login(@Valid @RequestBody LoginDTO loginDTO) {

    //Nạp input gồm username/password vào Security
    UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
        loginDTO.getUsername(), loginDTO.getPassword());

    //xác thực người dùng => cần viết hàm loadUserByUsername
    Authentication authentication = authenticationManagerBuilder.getObject()
        .authenticate(authenticationToken);

    //Create a token ( cơ chế của authentication này không lưu mk ng dùng khi login t/c)
    String access_token = this.securityUtil.createToken(authentication);
    SecurityContextHolder.getContext()
        .setAuthentication(authentication); //Lưu data vào Security Context

    RestLoginDTO res = new RestLoginDTO();
    User currentUserDB = userService.handleGetUserByUserName(loginDTO.getUsername());
    if (currentUserDB != null) {
      RestLoginDTO.UserLogin userLogin = new RestLoginDTO.UserLogin();
      userLogin.setId(currentUserDB.getId());
      userLogin.setEmail(currentUserDB.getEmail());
      userLogin.setName(currentUserDB.getName());
      res.setUser(userLogin);
    }

    res.setAccessToken(access_token);
    return ResponseEntity.ok().body(res);
  }
}
